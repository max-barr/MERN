import React from 'react';

const Person = (props) => {
    return (
        <div>
            <h2>I am a person!</h2>
        </div>
    )
}

export default Person;